# import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import logging
import numpy as np
from tqdm import tqdm
import torch
import json
import dgl
import dgl.sparse as dsp
from graphmae.utils import (
    build_args,
    create_optimizer,
    set_random_seed,
    TBLogger,
    get_current_lr,
    load_best_configs,
    loss_plt,
    compute_high_order_matrix,
    dgl_subgraph_sampling,
    tsne_visiable,
    pca_visiable,
)
from graphmae.datasets.data_util import load_dataset
from graphmae.evaluation import node_classification_evaluation
from graphmae.models import build_model


logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)


def pretrain(order,dataset_name, model, graph, feat, optimizer, max_epoch, device, scheduler, num_classes, lr_f, weight_decay_f, max_epoch_f, linear_prob, logger=None):
    logging.info("start training..")
    graph = graph.to(device)
    x = feat.to(device)

    epoch_iter = tqdm(range(max_epoch))
    train_loss = []
    if dataset_name == 'pubmed':
        pass
        graph,keep_nodes = dgl_subgraph_sampling(graph,int(graph.num_nodes()*0.9))
        x = x[keep_nodes]
        graph = graph.to(device)
        x = x.to(device)
        info = compute_high_order_matrix(graph,order)
    else:
        info = compute_high_order_matrix(graph,order)

    for epoch in epoch_iter:
        model.train()

        loss,noise_loss, loss_dict = model(graph, x, info, order)
        train_loss.append(noise_loss)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if scheduler is not None:
            scheduler.step()

        epoch_iter.set_description(f"# Epoch {epoch}: train_loss: {loss.item():.4f}")
        if logger is not None:
            loss_dict["lr"] = get_current_lr(optimizer)
            logger.note(loss_dict, step=epoch)

        if (epoch + 1) % 200 == 0:
            node_classification_evaluation(model, args.dataset,graph, x, num_classes, lr_f, weight_decay_f, max_epoch_f, device, linear_prob, mute=True)

    # return best_model
    # loss_plt(train_loss)
    return model


def main(args):
    device = args.device if args.device >= 0 else "cpu"
    if len(args.seeds) > 1:
        seeds = np.random.randint(0, 10000, size=10)
    else:
        seeds = args.seeds
    dataset_name = args.dataset
    max_epoch = args.max_epoch
    max_epoch_f = args.max_epoch_f
    num_hidden = args.num_hidden
    num_layers = args.num_layers
    encoder_type = args.encoder
    decoder_type = args.decoder
    replace_rate = args.replace_rate

    optim_type = args.optimizer
    loss_fn = args.loss_fn

    lr = args.lr
    weight_decay = args.weight_decay
    lr_f = args.lr_f
    weight_decay_f = args.weight_decay_f
    linear_prob = args.linear_prob
    load_model = args.load_model
    save_model = args.save_model
    logs = args.logging
    use_scheduler = args.scheduler


    order = args.order

    graph, (num_features, num_classes) = load_dataset(dataset_name,args)
    I = dsp.identity(shape=(graph.num_nodes(), graph.num_nodes())).to(graph.device)
    # lcc = getLCC(graph)
    args.num_features = num_features

    acc_list = []
    estp_acc_list = []
    for i, seed in enumerate(seeds):
        print(f"####### Run {i} for seed {seed}")
        set_random_seed(seed)

        if logs:
            logger = TBLogger(name=f"{dataset_name}_loss_{loss_fn}_rpr_{replace_rate}_nh_{num_hidden}_nl_{num_layers}_lr_{lr}_mp_{max_epoch}_mpf_{max_epoch_f}_wd_{weight_decay}_wdf_{weight_decay_f}_{encoder_type}_{decoder_type}")
        else:
            logger = None

        model = build_model(args)
        model.to(device)
        optimizer = create_optimizer(optim_type, model, lr, weight_decay)

        if use_scheduler:
            logging.info("Use schedular")
            scheduler = lambda epoch :( 1 + np.cos((epoch) * np.pi / max_epoch) ) * 0.5
            # scheduler = lambda epoch: epoch / warmup_steps if epoch < warmup_steps \
                    # else ( 1 + np.cos((epoch - warmup_steps) * np.pi / (max_epoch - warmup_steps))) * 0.5
            scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=scheduler)
        else:
            scheduler = None

        x = graph.ndata["feat"]
        if not load_model:
            model = pretrain(order,dataset_name, model, graph, x, optimizer, max_epoch, device, scheduler, num_classes, lr_f, weight_decay_f, max_epoch_f, linear_prob, logger)
            model = model.cpu()

        if load_model:
            logging.info("Loading Model ... ")
            '''
            cora.pt   our
            MAE_cora.pt   GraphMAE
            '''
            model.load_state_dict(torch.load("./netmodel/mettackAL_{}_{}.pt".format(args.dataset,seed)))
        if save_model:
            logging.info("Saveing Model ...")
            torch.save(model.state_dict(), "./netmodel/mettackAL_{}_{}.pt".format(args.dataset,seed))

        model = model.to(device)
        # tsne_visiable(model,graph,x,device)
        model.eval()

        final_acc, estp_acc = node_classification_evaluation(model, args.dataset,graph, x, num_classes, lr_f, weight_decay_f, max_epoch_f, device, linear_prob)
        acc_list.append(final_acc)
        estp_acc_list.append(estp_acc)

        if logger is not None:
            logger.finish()

    final_acc, final_acc_std = np.mean(acc_list), np.std(acc_list)
    estp_acc, estp_acc_std = np.mean(estp_acc_list), np.std(estp_acc_list)
    # print(f"# final_acc: {final_acc:.4f}±{final_acc_std:.4f}")
    # print(f"# early-stopping_acc: {estp_acc:.4f}±{estp_acc_std:.4f}")
    print(f"{{{final_acc:.4f},{estp_acc:.4f}}}")
    # result = {
    #     "accuracy": final_acc,
    #     "stopping": estp_acc
    # }
    # print(json.dumps(result))


# Press the green button in the gutter to run the script.
if __name__ == "__main__":
    args = build_args()
    if args.use_cfg:
        args = load_best_configs(args, "configs.yml")
    print(args)
    main(args)
