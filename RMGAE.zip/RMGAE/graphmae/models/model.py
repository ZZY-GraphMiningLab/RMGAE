from typing import Optional
from itertools import chain
from functools import partial
import torch.nn.functional as F
import torch
import torch.nn as nn

from .gin import GIN
from .gat import GAT
from .gcn import GCN
from .dot_gat import DotGAT
from .loss_func import sce_loss, reconstruct
from .lcc import pre_clean, getLCC
from graphmae.utils import create_norm, drop_edge, compute_high_order_matrix, get_weighttensor, get_knn
import dgl

class K2GCN(torch.nn.Module):
    def __init__(
            self,
            in_dim: int,
            num_hidden: int,
            num_layers: int,
            dropout: float,
            activation: str,
            residual: bool,
            norm: Optional[str],
            enc_dec="encoding",
    ):
        self.encoder = GCN(
            in_dim=in_dim,
            num_hidden=num_hidden,
            out_dim=num_hidden,
            num_layers=num_layers,
            dropout=dropout,
            activation=activation,
            residual=residual,
            norm=create_norm(norm),
            encoding=(enc_dec == "encoding")
        )

