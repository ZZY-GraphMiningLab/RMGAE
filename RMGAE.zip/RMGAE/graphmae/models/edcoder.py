from typing import Optional
from itertools import chain
from functools import partial
import torch.nn.functional as F
import torch
import torch.nn as nn

from .gin import GIN
from .gat import GAT
from .gcn import GCN
from .dot_gat import DotGAT
from .loss_func import sce_loss#, reconstruct
from .lcc import pre_clean, getLCC
from graphmae.utils import create_norm, drop_edge, compute_high_order_matrix, get_weighttensor, get_knn, dgl_subgraph_sampling
import dgl
import dgl.function as fn

def setup_module(m_type, enc_dec, in_dim, num_hidden, out_dim, num_layers, dropout, activation, residual, norm, nhead, nhead_out, attn_drop, negative_slope=0.2, concat_out=True) -> nn.Module:
    if m_type == "gat":
        mod = GAT(
            in_dim=in_dim,
            num_hidden=num_hidden,
            out_dim=out_dim,
            num_layers=num_layers,
            nhead=nhead,
            nhead_out=nhead_out,
            concat_out=concat_out,
            activation=activation,
            feat_drop=dropout,
            attn_drop=attn_drop,
            negative_slope=negative_slope,
            residual=residual,
            norm=create_norm(norm),
            encoding=(enc_dec == "encoding"),
        )
    elif m_type == "dotgat":
        mod = DotGAT(
            in_dim=in_dim,
            num_hidden=num_hidden,
            out_dim=out_dim,
            num_layers=num_layers,
            nhead=nhead,
            nhead_out=nhead_out,
            concat_out=concat_out,
            activation=activation,
            feat_drop=dropout,
            attn_drop=attn_drop,
            residual=residual,
            norm=create_norm(norm),
            encoding=(enc_dec == "encoding"),
        )
    elif m_type == "gin":
        mod = GIN(
            in_dim=in_dim,
            num_hidden=num_hidden,
            out_dim=out_dim,
            num_layers=num_layers,
            dropout=dropout,
            activation=activation,
            residual=residual,
            norm=norm,
            encoding=(enc_dec == "encoding"),
        )
    elif m_type == "gcn":
        mod = GCN(
            in_dim=in_dim,
            num_hidden=num_hidden,
            out_dim=out_dim,
            num_layers=num_layers,
            dropout=dropout,
            activation=activation,
            residual=residual,
            norm=create_norm(norm),
            encoding=(enc_dec == "encoding")
        )
    elif m_type == "mlp":
        # * just for decoder
        mod = nn.Sequential(
            nn.Linear(in_dim, num_hidden),
            nn.PReLU(),
            nn.Dropout(0.2),
            nn.Linear(num_hidden, out_dim)
        )
    elif m_type == "linear":
        mod = nn.Linear(in_dim, out_dim)
    else:
        raise NotImplementedError

    return mod


class PreModel(nn.Module):
    def __init__(
            self,
            in_dim: int,
            num_hidden: int,
            num_layers: int,
            nhead: int,
            nhead_out: int,
            activation: str,
            feat_drop: float,
            attn_drop: float,
            negative_slope: float,
            residual: bool,
            norm: Optional[str],
            knn_num: int,
            cl_weight: float,
            stru_weight: float,
            tmp: float,
            mask_rate: float = 0.3,
            encoder_type: str = "gat",
            decoder_type: str = "gat",
            loss_fn: str = "sce",
            drop_edge_rate: float = 0.0,
            replace_rate: float = 0.1,
            alpha_l: float = 2,
            concat_hidden: bool = False,


         ):
        super(PreModel, self).__init__()
        self._mask_rate = mask_rate

        self._encoder_type = encoder_type
        self._decoder_type = decoder_type
        self._drop_edge_rate = drop_edge_rate
        self._output_hidden_size = num_hidden
        self._concat_hidden = concat_hidden

        self._replace_rate = replace_rate
        self._mask_token_rate = 1 - self._replace_rate
        self.sft = nn.Softmax(dim=1)

        self.k_num = knn_num
        self.tmp = tmp
        self.cl_weight = cl_weight
        self.stru_weight = stru_weight

        assert num_hidden % nhead == 0
        assert num_hidden % nhead_out == 0
        if encoder_type in ("gat", "dotgat"):
            enc_num_hidden = num_hidden // nhead
            enc_nhead = nhead
        else:
            enc_num_hidden = num_hidden
            enc_nhead = 1

        dec_in_dim = num_hidden
        dec_num_hidden = num_hidden // nhead_out if decoder_type in ("gat", "dotgat") else num_hidden

        # build encoder
        self.encoder = setup_module(
            m_type=encoder_type,
            enc_dec="encoding",
            in_dim=in_dim,
            num_hidden=enc_num_hidden,
            out_dim=enc_num_hidden,
            num_layers=num_layers,
            nhead=enc_nhead,
            nhead_out=enc_nhead,
            concat_out=True,
            activation=activation,
            dropout=feat_drop,
            attn_drop=attn_drop,
            negative_slope=negative_slope,
            residual=residual,
            norm=norm,
        )

        # build decoder for attribute prediction
        self.decoder = setup_module(
            m_type=decoder_type,
            enc_dec="decoding",
            in_dim=dec_in_dim,
            num_hidden=dec_num_hidden,
            out_dim=in_dim,
            num_layers=1,
            nhead=nhead,
            nhead_out=nhead_out,
            activation=activation,
            dropout=feat_drop,
            attn_drop=attn_drop,
            negative_slope=negative_slope,
            residual=residual,
            norm=norm,
            concat_out=True,
        )

        self.enc_mask_token = nn.Parameter(torch.zeros(1, in_dim))
        if concat_hidden:
            self.encoder_to_decoder = nn.Linear(dec_in_dim * num_layers, dec_in_dim, bias=False)
        else:
            self.encoder_to_decoder = nn.Linear(dec_in_dim, dec_in_dim, bias=False)

        # * setup loss function
        self.criterion = self.setup_loss_fn(loss_fn, alpha_l)

        self.fc1 = torch.nn.Linear(num_hidden, num_hidden)
        self.fc2 = torch.nn.Linear(num_hidden, num_hidden)
        # self.projector_fc1 = nn.Sequential(nn.Linear(num_hidden, num_hidden, bias=False),
        #                                    nn.PReLU(),
        #                                    nn.Linear(num_hidden, num_hidden, bias=False)
        #                                    )
        # self.projector_fc2 = nn.Sequential(nn.Linear(num_hidden, num_hidden, bias=False),
        #                                    nn.PReLU(),
        #                                    nn.Linear(num_hidden, num_hidden, bias=False)
        #                                    )

        # self.tanh = nn.Tanh()
        self.sigmoid = nn.Sigmoid()

    @property
    def output_hidden_dim(self):
        return self._output_hidden_size

    def setup_loss_fn(self, loss_fn, alpha_l):
        if loss_fn == "mse":
            criterion = nn.MSELoss()
        elif loss_fn == "sce":
            criterion = partial(sce_loss, alpha=alpha_l)
        else:
            raise NotImplementedError
        return criterion

    def encoding_mask_noise(self, g, x, mask_rate=0.3):
        num_nodes = g.num_nodes()
        perm = torch.randperm(num_nodes, device=x.device)
        num_mask_nodes = int(mask_rate * num_nodes)

        # random masking
        num_mask_nodes = int(mask_rate * num_nodes)
        mask_nodes = perm[: num_mask_nodes]
        keep_nodes = perm[num_mask_nodes: ]

        if self._replace_rate > 0:
            num_noise_nodes = int(self._replace_rate * num_mask_nodes)
            perm_mask = torch.randperm(num_mask_nodes, device=x.device)
            token_nodes = mask_nodes[perm_mask[: int(self._mask_token_rate * num_mask_nodes)]]
            noise_nodes = mask_nodes[perm_mask[-int(self._replace_rate * num_mask_nodes):]]
            noise_to_be_chosen = torch.randperm(num_nodes, device=x.device)[:num_noise_nodes]

            out_x = x.clone()
            out_x[token_nodes] = 0.0
            out_x[noise_nodes] = x[noise_to_be_chosen]
        else:
            out_x = x.clone()
            token_nodes = mask_nodes
            out_x[mask_nodes] = 0.0

        out_x[token_nodes] += self.enc_mask_token
        use_g = g.clone()

        return use_g, out_x, (mask_nodes, keep_nodes)

    def forward(self, g, x, info, order):
        # ---- attribute reconstruction ----
        loss,R = self.mask_attr_prediction(g, x, info, order)
        loss_item = {"loss": loss.item()}
        return loss,R.item(), loss_item

    def mask_attr_prediction(self, g, x, info, order):

        '''
            截取子图
        '''
        # g,keep_nodes = dgl_subgraph_sampling(g,int(g.num_nodes()*0.9))
        # x = x[keep_nodes]

        #生成拓扑视图(原图)和特征视图（KNN）



        # knn_g = get_knn(g.num_nodes(), x,5,'cosine').to(x.device)
        '''
            70 60.41
            100
        '''
        # k = 40
        sim = F.normalize(x).mm(F.normalize(x).T).fill_diagonal_(0.0)
        dst = sim.topk(self.k_num, 1)[1]
        src = torch.arange(x.size(0)).unsqueeze(1).expand_as(sim.topk(self.k_num, 1)[1]).to(x.device)
        edge_index = torch.stack([src.reshape(-1), dst.reshape(-1)])
        knn_g = dgl.graph((edge_index[0], edge_index[1]), num_nodes=g.num_nodes())
        knn_g = knn_g.remove_self_loop()
        knn_g = knn_g.add_self_loop()

        # info = compute_high_order_matrix(g).to(x.device)
        pre_use_g, use_x, (mask_nodes, keep_nodes) = self.encoding_mask_noise(g, x, self._mask_rate)


        if self._drop_edge_rate > 0:
            use_g, masked_edges = drop_edge(pre_use_g, self._drop_edge_rate, return_edges=True)
        else:
            use_g = pre_use_g

        enc_rep, all_hidden = self.encoder(use_g, use_x, return_hidden=True)

        knn_rep, knn_hidden = self.encoder(knn_g, x, return_hidden=True)

        bis = self.get_score_all_pairs(g,enc_rep)
        weight_tensor,adj = get_weighttensor(g)
        if order > 1:
            R = self.robust_reconstruct(enc_rep, info, weight_tensor,bis,threshold=None)
        else:
            R = self.first_order_reconstruction(enc_rep, g, 1)


        if self._concat_hidden:
            enc_rep = torch.cat(all_hidden, dim=1)

        # ---- attribute reconstruction ----
        rep = self.encoder_to_decoder(enc_rep)

        if self._decoder_type not in ("mlp", "linear"):
            # * remask, re-mask
            rep[mask_nodes] = 0

        if self._decoder_type in ("mlp", "liear") :
            recon = self.decoder(rep)
        else:
            recon = self.decoder(pre_use_g, rep)

        x_init = x[mask_nodes]
        x_rec = recon[mask_nodes]
        intra_cl_loss = self.contrastive_loss(enc_rep, knn_rep, self.tmp,sub=False,batch_size=0)
        # inter_cl_loss = self.contrastive_loss(sub_rep, knn_rep, 0.4,sub=True,batch_size=0)

        # pos_cl_loss = self.pos_cl(enc_rep, knn_rep, sub_rep,0.5)
        if order > 1:
            loss = self.criterion(x_rec, x_init)  + intra_cl_loss * self.cl_weight + R * self.stru_weight
        # else:
        #     loss = self.criterion(x_rec, x_init) + intra_cl_loss  + R
        return loss,loss

    def embed(self, g, x):

        rep = self.encoder(g, x)
        return rep

    @property
    def enc_params(self):
        return self.encoder.parameters()

    @property
    def dec_params(self):
        return chain(*[self.encoder_to_decoder.parameters(), self.decoder.parameters()])

    # def reconstruct(self, prob, stru, weight_tensor):
    #     b_xent = nn.BCEWithLogitsLoss(weight=weight_tensor)
    #     R = b_xent(torch.matmul(prob, prob.t()), stru)
    #     return R

    # def robust_reconstruct(self,prob, info, g, edge_score, threshold=None,num_neg_samples=10):
    #     """
    #     稀疏边表示的鲁棒结构重建损失（适用于大图）
    #
    #     参数：
    #         prob        : [N, D] 节点嵌入表示
    #         pos_src     : [E] 边的起点索引（source）
    #         pos_dst     : [E] 边的终点索引（destination）
    #         base_weight : [E] 每条边的基本权重（可选，用于平衡正负样本）
    #         edge_score  : [E] 每条边的可信评分（注意力/相似度等）
    #         threshold   : 用于二值掩码的阈值（可选）
    #
    #     返回：
    #         loss        : BCE重建损失（稀疏版本）
    #     """
    #
    #     N = prob.shape[0]
    #     edge_score = edge_score.detach()
    #     pos_src, pos_dst = g.edges()
    #     num_pos = pos_src.shape[0]
    #     num_neg = num_pos * num_neg_samples
    #     neg_src = torch.randint(0, N, (num_neg,), device=prob.device)
    #     neg_dst = torch.randint(0, N, (num_neg,), device=prob.device)
    #     prob = F.normalize(prob)
    #     z_src = prob[pos_src]
    #     z_dst = prob[pos_dst]
    #     z_neg_src = prob[neg_src]
    #     z_neg_dst = prob[neg_dst]
    #     pos_logits = (z_src * z_dst).sum(dim=1)  # [num_pos_edges]
    #     neg_logits = (z_neg_src * z_neg_dst).sum(dim=1)
    #     # 标签与权重
    #     labels = torch.cat([
    #         info[pos_src, pos_dst], # 提取图中实际边对应的 A 中得分,
    #         torch.zeros_like(neg_logits)
    #     ])
    #
    #     weights = torch.cat([
    #         edge_score*10,
    #         torch.zeros_like(neg_logits)
    #     ])
    #     logits = torch.cat([pos_logits, neg_logits])
    #     loss = F.binary_cross_entropy_with_logits(logits, labels, weight=weights)
    #     return loss
    def negative_sampling_dgl(self, g, num_neg=1):
        """
        在 DGL 图上采样负边（不与正边重复），返回负边的 src 和 dst
        g: DGLGraph
        num_neg: 每条正边采样多少负边
        """
        device = g.device
        src, dst = g.edges()
        N = g.num_nodes()

        # 每条正边重复 num_neg 次
        neg_src = src.repeat_interleave(num_neg)
        neg_dst = torch.randint(0, N, (len(neg_src),), device=device)

        # 避免自环
        mask = neg_src != neg_dst
        neg_src, neg_dst = neg_src[mask], neg_dst[mask]

        # 避免负边与正边冲突
        # 构造正边索引集合
        # edge_set = set((int(s), int(d)) for s, d in zip(src, dst))
        # # mask: 负边不在正边集合中
        # mask2 = torch.tensor([(int(s), int(d)) not in edge_set for s, d in zip(neg_src, neg_dst)], device=device)
        # neg_src, neg_dst = neg_src[mask2], neg_dst[mask2]

        return neg_src, neg_dst
    def first_order_reconstruction(self, prob, g, num_neg):
        # device = g.device
        # N = prob.shape[0]
        prob = F.normalize(prob)
        # logits = torch.matmul(prob, prob.t())
        src, dst = g.edges()
        # 随机采样负边 (避免正边冲突)
        neg_src, neg_dst = self.negative_sampling_dgl(g, num_neg)

        pos_score = (prob[src] * prob[dst]).sum(dim=-1)  # 内积解码
        neg_score = (prob[neg_src] * prob[neg_dst]).sum(dim=-1)
        # === 4. 构造标签并计算 BCEWithLogitsLoss ===
        pos_loss = F.binary_cross_entropy(pos_score.sigmoid(), torch.ones_like(pos_score))
        neg_loss = F.binary_cross_entropy(neg_score.sigmoid(), torch.zeros_like(neg_score))

        loss = pos_loss+neg_loss

        return loss
    def robust_reconstruct(self, prob, stru, base_weight, edge_score, threshold=None):
        """
        结合边评分的鲁棒结构重建（结构来自攻击图，但部分边可信）。

        参数：
            prob         : [N, D] 节点嵌入
            stru         : [N, N] 当前图的结构（攻击图）
            base_weight  : [N, N] BCE损失的基本权重（如用来平衡正负样本数量）
            edge_score   : [N, N] 每条边的重要性评分（由注意力、特征相似度等计算）
            threshold    : 可选，用于将 edge_score 二值化为 hard mask（0/1）

        返回：
            loss : 鲁棒结构重建损失
        """
        prob = F.normalize(prob)
        logits = torch.matmul(prob, prob.t())  # 重建边 logits

        # prob = self.sft(prob)
        # logits = torch.matmul(prob, prob.t())

        if threshold is not None:
            edge_mask = (edge_score > threshold).float()  # hard mask
        else:
            edge_mask = edge_score  # soft mask（如注意力分数）

        # 基础权重（平衡正负样本） × 信任掩码（抑制不可信边）
        combined_weight = edge_mask * base_weight
        combined_weight = combined_weight.detach()

        loss_fn = nn.BCEWithLogitsLoss(weight=combined_weight)
        loss = loss_fn(logits, stru)

        return loss

    def projection(self, z: torch.Tensor) -> torch.Tensor:
        z = F.elu(self.fc1(z))
        return self.fc2(z)

    def sim(self, z1: torch.Tensor, z2: torch.Tensor):
        z1 = F.normalize(z1)
        z2 = F.normalize(z2)
        return torch.mm(z1, z2.t())
    #
    def semi_loss(self, z1: torch.Tensor, z2: torch.Tensor,tau):
        f = lambda x: torch.exp(x / tau)
        refl_sim = f(self.sim(z1, z1))
        between_sim = f(self.sim(z1, z2))

        return -torch.log(
            between_sim.diag()
            / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))

    def batched_semi_loss(self, z1: torch.Tensor, z2: torch.Tensor,
                          batch_size: int,tau: int):
        # Space complexity: O(BN) (semi_loss: O(N^2))
        device = z1.device
        num_nodes = z1.size(0)
        num_batches = (num_nodes - 1) // batch_size + 1
        f = lambda x: torch.exp(x / tau)
        indices = torch.arange(0, num_nodes).to(device)
        losses = []

        for i in range(num_batches):
            mask = indices[i * batch_size:(i + 1) * batch_size]
            refl_sim = f(self.sim(z1[mask], z1))  # [B, N]
            between_sim = f(self.sim(z1[mask], z2))  # [B, N]

            losses.append(-torch.log(
                between_sim[:, i * batch_size:(i + 1) * batch_size].diag()
                / (refl_sim.sum(1) + between_sim.sum(1)
                   - refl_sim[:, i * batch_size:(i + 1) * batch_size].diag())))

        return torch.cat(losses)

    def contrastive_loss(self, z1: torch.Tensor, z2: torch.Tensor,tau,sub: bool = False,
             mean: bool = True, batch_size: int = 0):
        # h1 = self.projector_fc1(z1)
        # h2 = self.projector_fc1(z2)
        # if not sub:
        #     h2 = self.projector_fc2(z2)
        # else:
        #     h2 = self.projector_fc1(z2)
        h1 = self.projection(z1)
        h2 = self.projection(z2)

        if batch_size == 0:
            l1 = self.semi_loss(h1, h2,tau)
            l2 = self.semi_loss(h2, h1,tau)
        else:
            l1 = self.batched_semi_loss(h1, h2, batch_size,tau)
            l2 = self.batched_semi_loss(h2, h1, batch_size,tau)

        ret = (l1 + l2) * 0.5
        ret = ret.mean() if mean else ret.sum()

        return ret

    # def pos_cl(self, z1: torch.Tensor, z2: torch.Tensor, z3: torch.Tensor, tau, mean: bool = True):
    #     h1 = self.projector_fc1(z1)  # anchor: enc
    #     h2 = self.projector_fc1(z2)  # knn view
    #     h3 = self.projector_fc2(z3)  # subgraph view
    #
    #     # Compute similarity
    #     sim12 = self.sim(h1, h2) / tau  # N x N
    #     sim13 = self.sim(h1, h3) / tau  # N x N
    #
    #     # Positive pairs (i-th diagonal elements)
    #     pos_sim = torch.exp(sim12.diag()) + torch.exp(sim13.diag())  # N
    #
    #     # All similarities (negatives)
    #     neg_sim = torch.exp(sim12).sum(dim=1) + torch.exp(sim13).sum(dim=1)  # N
    #
    #     # Final loss
    #     loss = -torch.log(pos_sim / neg_sim)
    #
    #     return loss.mean() if mean else loss

    '''
        稀疏矩阵版本
    '''
    # def get_score(self,graph, x):
    #     deg = graph.in_degrees().float() + 1e-6  # 避免除以0
    #     src, dst = graph.edges()
    #     # deg_weight = -torch.log(((1/deg[graph.edges()[1]] + 1e-6)).pow_(2))
    #     deg_weight = -torch.log((1 / deg[src]).pow(2))  # [E]
    #     src, dst = graph.edges()
    #     src_feat = x[src]
    #     dst_feat = x[dst]
    #     feature_based = F.cosine_similarity(src_feat, dst_feat)
    #     # feature_based = (src_feat * dst_feat).sum(dim=-1, keepdim=True)
    #     bis = feature_based * deg_weight
    #     # bis = self.sigmoid(bis)
    #     # bis = (bis - bis.min()) / (bis.max() - bis.min() + 1e-8)
    #     bis = bis ** 2
    #     return bis

    '''
        稠密图版本
    '''

    def get_score_all_pairs(self, graph, x):
        """
        为图中每一对节点计算置信度分数：cosine(x_i, x_j) * degree_penalty(i, j)
        """
        N = graph.num_nodes()

        # 特征归一化（便于余弦相似度计算）
        x = F.normalize(x, dim=1)  # [N, F]


        cosine_sim = ((self.sim(x, x) + 1.0) / 2.0).clamp(0.0, 1.0)

        # 获取度并构造惩罚项
        deg = graph.in_degrees().float().clamp(min=1e-6)  # [N]
        deg_penalty = -torch.log((1 / deg).pow(2))  # [N]

        # 构造 pair-wise 惩罚矩阵
        deg_penalty_matrix = (deg_penalty.view(-1, 1) + deg_penalty.view(1, -1)) / 2  # [N, N]
        # min_val = deg_penalty_matrix.min()
        # max_val = deg_penalty_matrix.max()
        # deg_penalty_matrix = (deg_penalty_matrix - min_val) / (max_val - min_val + 1e-8)
        # 最终 score 矩阵
        score_matrix = cosine_sim * deg_penalty_matrix  # [N, N]
        score_matrix.fill_diagonal_(0.0)

        # 可选：加权强调高置信度
        # score_matrix = score_matrix ** 2  # 平方加权（可选）

        return score_matrix

    def get_score(self, graph, x):
        N = graph.num_nodes()
        src, dst = graph.edges()

        # 节点入度
        deg = graph.in_degrees().float() + 1e-6  # 避免除以0
        x = F.normalize(x)
        # 置信度 = 特征相似度 × 度惩罚项  ??用src??还是dst??还是平均
        deg_weight = (-torch.log((1 / deg[src]).pow(2)) -torch.log((1 / deg[dst]).pow(2)))/2 # [E]

        src_feat = x[src]  # [E, F]
        dst_feat = x[dst]  # [E, F]

        feature_based = F.cosine_similarity(src_feat, dst_feat)  # [E]
        edge_score = feature_based * deg_weight  # [E]

        # 构造一个稀疏矩阵，再转稠密
        edge_indices = torch.stack([src, dst], dim=0)  # [2, E]
        score_matrix = torch.sparse_coo_tensor(
            indices=edge_indices,
            values=edge_score,
            size=(N, N)
        ).to_dense()

        score_matrix = score_matrix ** 2
        return score_matrix  # shape [N, N]
    #
    # def compute_subgraph_representation(self, g, z, edge_score, fanout=10):
    #     """
    #     g: DGLGraph
    #     z: Tensor of shape (N, num_hidden), node representations
    #     edge_score: Tensor of shape (num_edges,), edge importance score
    #     fanout: int, how many neighbors to sample per node
    #     """
    #
    #     # 把边的打分挂到图上
    #     g.edata['score'] = edge_score
    #     '''
    #         对图的每一个源节点邻居进行采样，重点采样分数较高的节点，并将采样到的特征通过readout的形式聚合到源节点上，最后返回一个N*numhidden的tensor
    #     '''
    #     # 邻居采样，根据边权重分布进行加权采样
    #     sampled_g = dgl.sampling.sample_neighbors(
    #         g,
    #         nodes=g.nodes(),  # 全部节点都采样
    #         fanout=fanout,
    #         prob='score',  # 使用边的 score 作为采样概率
    #         replace=False
    #     )
    #
    #     # # 获取边的起点和终点
    #     # src, dst = sampled_graph.edges()
    #     # src_z = z[src]  # 获取起点的表示，shape: (num_sampled_edges, num_hidden)
    #     #
    #     # # 用 segment_reduce 聚合每个 dst 的邻居表示
    #     # subgraph_rep = dgl.ops.segment_reduce(
    #     #     dst, src_z, 'mean'  # 以 dst 分组，对每个 dst 聚合 src_z
    #     # )
    #     # 把节点特征复制过去
    #     sampled_g.ndata['h'] = z
    #
    #     # 聚合采样到的邻居特征：mean 聚合（可改为 sum/max/attention）
    #     sampled_g.update_all(
    #         fn.copy_u('h', 'm'),  # 将邻居节点的 h 复制给消息 m
    #         fn.mean('m', 'h_neigh')  # 聚合邻居特征
    #     )
    #
    #     # Step 4: 获取聚合后的特征
    #     subgraph_rep = sampled_g.ndata['h_neigh']
    #
    #     # Step 5: 清理释放内存（可选）
    #     del sampled_g
    #     torch.cuda.empty_cache()
    #
    #     return subgraph_rep  # shape: (N, num_hidden)
