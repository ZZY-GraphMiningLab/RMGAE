import torch
import torch.nn.functional as F
import torch.nn as nn

def sce_loss(x, y, alpha=3):
    x = F.normalize(x, p=2, dim=-1)
    y = F.normalize(y, p=2, dim=-1)

    # loss =  - (x * y).sum(dim=-1)
    # loss = (x_h - y_h).norm(dim=1).pow(alpha)

    loss = (1 - (x * y).sum(dim=-1)).pow_(alpha)

    loss = loss.mean()
    return loss


def sig_loss(x, y):
    x = F.normalize(x, p=2, dim=-1)
    y = F.normalize(y, p=2, dim=-1)

    loss = (x * y).sum(1)
    loss = torch.sigmoid(-loss)
    loss = loss.mean()
    return loss

def reconstruct(prob, stru, weight_tensor):
    b_xent = nn.BCEWithLogitsLoss(weight=weight_tensor)
    R = b_xent(torch.matmul(prob, prob.t()), stru)
    return R

def sim( z1: torch.Tensor, z2: torch.Tensor):
    z1 = F.normalize(z1)
    z2 = F.normalize(z2)
    return torch.mm(z1, z2.t())


def semi_loss( z1: torch.Tensor, z2: torch.Tensor,temp=0.5):
    f = lambda x: torch.exp(x / temp)
    refl_sim = f(sim(z1, z1))
    between_sim = f(sim(z1, z2))
    return -torch.log(between_sim.diag() / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))


def contrastive_loss( z1: torch.Tensor, z2: torch.Tensor,temp):
    l1 = semi_loss(z1,z2,temp)
    l2 = semi_loss(z2,z1,temp)
    loss = (l1+l2)*0.5
    return loss.mean()