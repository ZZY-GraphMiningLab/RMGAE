import torch
import dgl
import networkx as nx

def get_neighbors(g, u, include_self_loop=True):
    neighbors = torch.cat([g.predecessors(u), g.successors(u)]).unique()
    if include_self_loop:
        neighbors = neighbors[neighbors != u.item()]
    return neighbors

def getLCC(g):
    # 转换为无向图
    g.cpu()
    g = g.remove_self_loop()
    # 转换为NetworkX无向图
    nx_graph = nx.Graph()
    nx_graph.add_nodes_from(range(g.num_nodes()))
    src, dst = g.edges()
    edges = list(zip(src.tolist(), dst.tolist()))  # 获取边列表
    nx_graph.add_edges_from(edges)  # 添加所有边
    # 计算局部聚类系数
    lcc_dict = nx.clustering(nx_graph)

    # 转为 tensor，确保顺序与原始图一致
    lcc_tensor = torch.tensor([lcc_dict[i] for i in range(g.num_nodes())], dtype=torch.float)

    # lcc = []
    # dgl.to_networkx(g.cpu(), g.ndata, g.edata)
    # for node in g.nodes():
    #     neighbors = get_neighbors(g, node, include_self_loop=True)
    #     k = len(neighbors)
    #     if k<2:
    #         clustering=0
    #     else:
    #         triplets=0
    #         for i in range(k):
    #             for j in range(i+1,k):
    #                 if g.has_edges_between(neighbors[i], neighbors[j]):
    #                     triplets += 1
    #         clustering = 2*triplets/(k*(k-1))
    #     lcc.append(clustering)
    return lcc_tensor

def pre_clean(g, lcc_score):

    lcc_avg = torch.mean(lcc_score)*0.5
    src, dst = g.edges()
    edge_save = (lcc_score[src] + lcc_score[dst]) / 2
    mask = edge_save > lcc_avg
    new_g = dgl.graph((src[mask], dst[mask]), num_nodes=g.num_nodes())
    new_g = new_g.remove_self_loop()
    new_g = new_g.add_self_loop()
    return new_g