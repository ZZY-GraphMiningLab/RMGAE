import os
import argparse
import random
import yaml
import logging
from functools import partial
import numpy as np

import dgl

import torch
import torch.nn as nn
from torch import optim as optim
from tensorboardX import SummaryWriter
import scipy.sparse as sp
from sklearn.neighbors import kneighbors_graph
from torch_geometric.utils import remove_self_loops
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA

logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)

def pca_visiable(model, graph, x, device):
    model.eval()
    graph = graph.to(device)
    x = x.to(device)

    # === 1. 获取节点嵌入 ===
    with torch.no_grad():
        embeddings = model.embed(graph, x)
        embeddings = embeddings.detach().cpu().numpy()

    # === 2. 提取测试节点及标签 ===
    labels = graph.ndata['label'].cpu().numpy()
    test_mask = graph.ndata['test_mask'].cpu().numpy()

    embeddings_test = embeddings[test_mask]
    labels_test = labels[test_mask]

    # === 3. 执行 PCA 降维 ===
    pca = PCA(n_components=2, random_state=42)
    embeddings_2d = pca.fit_transform(embeddings_test)

    # === 4. 绘制散点图 ===
    plt.figure(figsize=(8, 6))
    num_classes = len(np.unique(labels_test))
    for i in range(num_classes):
        idx = labels_test == i
        plt.scatter(embeddings_2d[idx, 0], embeddings_2d[idx, 1],
                    s=10, alpha=0.7, label=f'Class {i}')

    # 移除所有坐标轴元素和图例
    plt.axis('off')

    # === 5. 保存图片 ===
    os.makedirs("./imgs", exist_ok=True)
    save_path = os.path.join("./imgs", "ALpca.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

    print(f"PCA 可视化图已保存到: {save_path}")
def accuracy(y_pred, y_true):
    y_true = y_true.squeeze().long()
    preds = y_pred.max(1)[1].type_as(y_true)
    correct = preds.eq(y_true).double()
    correct = correct.sum().item()
    return correct / len(y_true)


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.determinstic = True

def compute_high_order_matrix(g,order):
    """
    g: DGLGraph (必须在 device 上)
    field: list, 不同阶的权重，例如 [1.0, 0.1, 0.01]
    return: torch.Tensor [N, N], 稠密高阶加权邻接矩阵 (CUDA)
    """
    all_weights = [1.0, 0.1, 0.01, 0.001, 0.0001]
    device = g.device
    N = g.num_nodes()
    # field = [10 ** (-i) for i in range(order)]
    field = all_weights[:order]
    # -------- 获取邻接矩阵 --------

    src, dst = g.edges()  # 1D tensors, device 默认 CPU

    adj = torch.zeros((N, N), device=device)
    adj[src, dst] = 1.0
    adj[dst, src] = 1.0
    adj.fill_diagonal_(0)
    if order == 1:
        return adj
    # -------- 计算高阶加权邻接矩阵 --------
    current = adj.clone()
    stru = field[0] * adj

    for i in range(1, len(field)):
        current = torch.matmul(current, adj)
        stru = stru + field[i] * current

    # -------- 行归一化 --------
    rowsum = stru.sum(dim=1, keepdim=True)  # [N, 1]
    stru_norm = stru / rowsum.clamp(min=1.0)

    return stru_norm  # [N, N] dense

def tsne_visiable(model,graph,x,device):
    model.eval()
    graph = graph.to(device)
    x = x.to(device)
    with torch.no_grad():
        embeddings  = model.embed(graph.to(device), x.to(device))
        embeddings = embeddings.detach().cpu().numpy()
    labels = graph.ndata['label'].cpu().numpy()
    test_mask = graph.ndata['test_mask'].cpu().numpy()

    embeddings_test = embeddings[test_mask]
    labels_test = labels[test_mask]

    # === 3. 执行 t-SNE 降维 ===
    tsne = TSNE(
        n_components=2,
        perplexity=30,
        learning_rate=200,
        n_iter=1000,
        init='pca',
        random_state=42
    )
    embeddings_2d = tsne.fit_transform(embeddings_test)

    # === 4. 绘制散点图 ===
    plt.figure(figsize=(8, 6))
    num_classes = len(np.unique(labels_test))
    for i in range(num_classes):
        idx = labels_test == i
        plt.scatter(embeddings_2d[idx, 0], embeddings_2d[idx, 1],
                    s=10, alpha=0.7, label=f'Class {i}')

    # 移除所有坐标轴元素和图例
    plt.axis('off')

    # 只保留底部标题
    # plt.title("t-SNE Visualization of Test Node Embeddings", pad=20)
    # plt.show()
    # === 5. 保存图片 ===
    os.makedirs("./imgs", exist_ok=True)
    save_path = os.path.join("./imgs", "ALtsne.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

    print(f" t-SNE 可视化图已保存到: {save_path}")

# def compute_high_order_matrix(graph):
#     field = [1.0, 0.1, 0.001]
#     device = graph.device
#     num_nodes = graph.num_nodes()
#     src, dst = graph.edges()
#
#     # 构建稀疏邻接矩阵 (稀疏)
#     indices = torch.stack([src, dst], dim=0).to(torch.long).to(device)
#     values = torch.ones(indices.shape[1], dtype=torch.float32, device=device)
#     adj = torch.sparse_coo_tensor(indices, values, (num_nodes, num_nodes)).coalesce()
#
#     # 高阶累加
#     stru = field[0] * adj
#     current = adj
#     for i in range(1, len(field)):
#         current = torch.sparse.mm(current, adj)  # A^k
#         stru = stru + field[i] * current
#
#     # 行归一化 (sparse)
#     rowsum = torch.sparse.sum(stru, dim=1).to_dense()  # (N,)
#     r_inv = torch.pow(rowsum, -1)
#     r_inv[torch.isinf(r_inv)] = 0.
#
#     # 假设 stru 是一个 torch.sparse_coo_tensor
#     stru = stru.coalesce()
#     # 构建 D^-1 * A （只对每一行缩放，不转 dense）
#     r_inv_expand = r_inv[stru.indices()[0]]  # 取每个非零边对应的行归一化因子
#     stru = torch.sparse_coo_tensor(
#         stru.indices(),
#         stru.values() * r_inv_expand,
#         stru.size()
#     ).coalesce()
#
#     return stru  # (num_nodes, num_nodes) 稀疏张量
def dgl_subgraph_sampling(g1, sub_size):
    """
    从两个 DGLGraph 中采样相同的节点子图（用于对比学习）

    参数:
        g1, g2     : DGLGraph 对象（视图1和视图2）
        sub_size   : 子图节点数量

    返回:
        sg1, sg2   : 两个子图（包含相同节点但结构可能不同）
        nodes      : 被采样到的节点索引（原图中的编号）
    """
    num_nodes = g1.num_nodes()
    sub_size = min(sub_size, num_nodes)

    # 随机采样一组节点（相同）
    nodes = torch.randperm(num_nodes)[:sub_size]
    nodes = torch.sort(nodes)[0]
    nodes = nodes.to(g1.device)
    # 构造两个子图（保留节点特征和边）
    sg1 = dgl.node_subgraph(g1, nodes)
    # sg2 = dgl.node_subgraph(g2, nodes)
    sg1 = sg1.add_self_loop()
    # sg2 = sg2.add_self_loop()
    return sg1, nodes

def get_weighttensor(graph):
    src,dst = graph.edges()
    edges = torch.stack([src, dst], dim=0)
    v = torch.ones_like(src).to(graph.device)
    adj_label = torch.sparse.FloatTensor(edges, v, (graph.num_nodes(),graph.num_nodes()))
    weight_mask = adj_label.to_dense() == 1
    weight_tensor = torch.ones_like(weight_mask, dtype=torch.float32,requires_grad=False).to(graph.device)
    weight_tensor[weight_mask] = 10
    return weight_tensor, (adj_label.to_dense()).float()

def knn_graph(X, k=20, metric='minkowski'):
    X = X.cpu().detach().numpy()
    A = kneighbors_graph(X, n_neighbors=k, metric=metric)
    edge_index = sparse_mx_to_edge_index(A)
    edge_index, _ = remove_self_loops(edge_index)

    return edge_index

def get_knn(nodes, X, k=20,metric='minkowski'):
    knn_adj = knn_graph(X, k, metric)
    knn_g = dgl.graph((knn_adj[0], knn_adj[1]), num_nodes=nodes)
    knn_g = knn_g.remove_self_loop()
    knn_g = knn_g.add_self_loop()
    return knn_g
def sparse_mx_to_edge_index(sparse_mx):
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    row = torch.from_numpy(sparse_mx.row.astype(np.int64))
    col = torch.from_numpy(sparse_mx.col.astype(np.int64))
    edge_index = torch.stack([row, col], dim=0)

    return edge_index
def get_current_lr(optimizer):
    return optimizer.state_dict()["param_groups"][0]["lr"]

def loss_plt(loss_values):
    # 创建 x 轴数据，表示 epoch 的数量
    epochs = range(1, len(loss_values) + 1)
    # 绘制损失函数曲线
    plt.plot(epochs, loss_values, 'b-', label='Training Loss')

    # 添加标题和标签
    plt.title('Training Loss Curve')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    # 显示图例
    plt.legend()
    # 显示图形
    plt.show()
def build_args():
    parser = argparse.ArgumentParser(description="GAT")
    parser.add_argument("--seeds", type=int, nargs="+", default=[0])
    parser.add_argument("--dataset", type=str, default="cora")
    parser.add_argument("--device", type=int, default=-1)
    parser.add_argument("--max_epoch", type=int, default=200,
                        help="number of training epochs")
    parser.add_argument("--warmup_steps", type=int, default=-1)

    parser.add_argument("--num_heads", type=int, default=4,
                        help="number of hidden attention heads")
    parser.add_argument("--num_out_heads", type=int, default=1,
                        help="number of output attention heads")
    parser.add_argument("--num_layers", type=int, default=2,
                        help="number of hidden layers")
    parser.add_argument("--num_hidden", type=int, default=256,
                        help="number of hidden units")
    parser.add_argument("--residual", action="store_true", default=False,
                        help="use residual connection")
    parser.add_argument("--in_drop", type=float, default=.2,
                        help="input feature dropout")
    parser.add_argument("--attn_drop", type=float, default=.1,
                        help="attention dropout")
    parser.add_argument("--norm", type=str, default=None)
    parser.add_argument("--lr", type=float, default=0.005,
                        help="learning rate")
    parser.add_argument("--weight_decay", type=float, default=5e-4,
                        help="weight decay")
    parser.add_argument("--negative_slope", type=float, default=0.2,
                        help="the negative slope of leaky relu for GAT")
    parser.add_argument("--activation", type=str, default="prelu")
    parser.add_argument("--mask_rate", type=float, default=0.5)
    parser.add_argument("--drop_edge_rate", type=float, default=0.0)
    parser.add_argument("--replace_rate", type=float, default=0.0)

    parser.add_argument("--encoder", type=str, default="gat")
    parser.add_argument("--decoder", type=str, default="gat")
    parser.add_argument("--loss_fn", type=str, default="sce")
    parser.add_argument("--alpha_l", type=float, default=2, help="`pow`coefficient for `sce` loss")
    parser.add_argument("--optimizer", type=str, default="adam")
    
    parser.add_argument("--max_epoch_f", type=int, default=30)
    parser.add_argument("--lr_f", type=float, default=0.001, help="learning rate for evaluation")
    parser.add_argument("--weight_decay_f", type=float, default=0.0, help="weight decay for evaluation")
    parser.add_argument("--linear_prob", action="store_true", default=False)
    
    parser.add_argument("--load_model", action="store_true")
    parser.add_argument("--save_model", action="store_true")
    parser.add_argument("--use_cfg", action="store_true")
    parser.add_argument("--logging", action="store_true")
    parser.add_argument("--scheduler", action="store_true", default=False)
    parser.add_argument("--concat_hidden", action="store_true", default=False)

    # for graph classification
    parser.add_argument("--pooling", type=str, default="mean")
    parser.add_argument("--deg4feat", action="store_true", default=False, help="use node degree as input feature")
    parser.add_argument("--batch_size", type=int, default=32)

    #for attack
    parser.add_argument("--attack", type=str, default="clean")
    parser.add_argument("--ptb", type=float, default=0.0)
    parser.add_argument("--tmp", type=float, default=0.4, help="temp for cl")
    parser.add_argument("--k_num", type=int, default=10, help="number of knn neighbors")
    parser.add_argument("--cl_weight", type=float, default=0.1,help="weight for contrastive loss")
    parser.add_argument("--stru_weight", type=float, default=0.1, help="weight for high_order structure loss")
    parser.add_argument("--order", type=int, default=3)
    args = parser.parse_args()
    return args


def create_activation(name):
    if name == "relu":
        return nn.ReLU()
    elif name == "gelu":
        return nn.GELU()
    elif name == "prelu":
        return nn.PReLU()
    elif name is None:
        return nn.Identity()
    elif name == "elu":
        return nn.ELU()
    else:
        raise NotImplementedError(f"{name} is not implemented.")


def create_norm(name):
    if name == "layernorm":
        return nn.LayerNorm
    elif name == "batchnorm":
        return nn.BatchNorm1d
    elif name == "graphnorm":
        return partial(NormLayer, norm_type="groupnorm")
    else:
        return nn.Identity


def create_optimizer(opt, model, lr, weight_decay, get_num_layer=None, get_layer_scale=None):
    opt_lower = opt.lower()

    parameters = model.parameters()
    opt_args = dict(lr=lr, weight_decay=weight_decay)

    opt_split = opt_lower.split("_")
    opt_lower = opt_split[-1]
    if opt_lower == "adam":
        optimizer = optim.Adam(parameters, **opt_args)
    elif opt_lower == "adamw":
        optimizer = optim.AdamW(parameters, **opt_args)
    elif opt_lower == "adadelta":
        optimizer = optim.Adadelta(parameters, **opt_args)
    elif opt_lower == "radam":
        optimizer = optim.RAdam(parameters, **opt_args)
    elif opt_lower == "sgd":
        opt_args["momentum"] = 0.9
        return optim.SGD(parameters, **opt_args)
    else:
        assert False and "Invalid optimizer"

    return optimizer


# -------------------
def mask_edge(graph, mask_prob):
    E = graph.num_edges()

    mask_rates = torch.FloatTensor(np.ones(E) * mask_prob)
    masks = torch.bernoulli(1 - mask_rates)
    mask_idx = masks.nonzero().squeeze(1)
    return mask_idx


def drop_edge(graph, drop_rate, return_edges=False):
    if drop_rate <= 0:
        return graph

    n_node = graph.num_nodes()
    edge_mask = mask_edge(graph, drop_rate)
    src = graph.edges()[0]
    dst = graph.edges()[1]

    nsrc = src[edge_mask]
    ndst = dst[edge_mask]

    ng = dgl.graph((nsrc, ndst), num_nodes=n_node)
    ng = ng.add_self_loop()

    dsrc = src[~edge_mask]
    ddst = dst[~edge_mask]

    if return_edges:
        return ng, (dsrc, ddst)
    return ng


def load_best_configs(args, path):
    with open(path, "r") as f:
        configs = yaml.load(f, yaml.FullLoader)

    if args.dataset not in configs:
        logging.info("Best args not found")
        return args

    logging.info("Using best configs")
    configs = configs[args.dataset]

    for k, v in configs.items():
        if "lr" in k or "weight_decay" in k:
            v = float(v)
        setattr(args, k, v)
    print("------ Use best configs ------")
    return args


# ------ logging ------

class TBLogger(object):
    def __init__(self, log_path="./logging_data", name="run"):
        super(TBLogger, self).__init__()

        if not os.path.exists(log_path):
            os.makedirs(log_path, exist_ok=True)

        self.last_step = 0
        self.log_path = log_path
        raw_name = os.path.join(log_path, name)
        name = raw_name
        for i in range(1000):
            name = raw_name + str(f"_{i}")
            if not os.path.exists(name):
                break
        self.writer = SummaryWriter(logdir=name)

    def note(self, metrics, step=None):
        if step is None:
            step = self.last_step
        for key, value in metrics.items():
            self.writer.add_scalar(key, value, step)
        self.last_step = step

    def finish(self):
        self.writer.close()


class NormLayer(nn.Module):
    def __init__(self, hidden_dim, norm_type):
        super().__init__()
        if norm_type == "batchnorm":
            self.norm = nn.BatchNorm1d(hidden_dim)
        elif norm_type == "layernorm":
            self.norm = nn.LayerNorm(hidden_dim)
        elif norm_type == "graphnorm":
            self.norm = norm_type
            self.weight = nn.Parameter(torch.ones(hidden_dim))
            self.bias = nn.Parameter(torch.zeros(hidden_dim))

            self.mean_scale = nn.Parameter(torch.ones(hidden_dim))
        else:
            raise NotImplementedError
        
    def forward(self, graph, x):
        tensor = x
        if self.norm is not None and type(self.norm) != str:
            return self.norm(tensor)
        elif self.norm is None:
            return tensor

        batch_list = graph.batch_num_nodes
        batch_size = len(batch_list)
        batch_list = torch.Tensor(batch_list).long().to(tensor.device)
        batch_index = torch.arange(batch_size).to(tensor.device).repeat_interleave(batch_list)
        batch_index = batch_index.view((-1,) + (1,) * (tensor.dim() - 1)).expand_as(tensor)
        mean = torch.zeros(batch_size, *tensor.shape[1:]).to(tensor.device)
        mean = mean.scatter_add_(0, batch_index, tensor)
        mean = (mean.T / batch_list).T
        mean = mean.repeat_interleave(batch_list, dim=0)

        sub = tensor - mean * self.mean_scale

        std = torch.zeros(batch_size, *tensor.shape[1:]).to(tensor.device)
        std = std.scatter_add_(0, batch_index, sub.pow(2))
        std = ((std.T / batch_list).T + 1e-6).sqrt()
        std = std.repeat_interleave(batch_list, dim=0)
        return self.weight * sub / std + self.bias
