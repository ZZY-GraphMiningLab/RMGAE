import copy
from tqdm import tqdm
import torch
import torch.nn as nn
import numpy as np
from graphmae.utils import create_optimizer, accuracy
from deeprobust.graph.data import Dataset, PrePtbDataset, Dpr2Pyg, Pyg2Dpr
import dgl
from torch_geometric.utils import to_undirected, dense_to_sparse, to_dense_adj

import scipy.sparse as sp
def node_classification_evaluation(model, dataset,graph, x, num_classes, lr_f, weight_decay_f, max_epoch_f, device, linear_prob=True, mute=False):
    model.eval()

    # perturbed_adj = sp.load_npz(f'./dataset/dataset/cora_meta_adj_0.25.npz')
    # perturbed_data = PrePtbDataset(root='/tmp/',
    #                                name='cora',
    #                                attack_method='meta',
    #                                ptb_rate=0.25)
    # perturbed_adj = perturbed_data.adj
    # edge_index = dense_to_sparse(torch.from_numpy(perturbed_adj.toarray()))[0].long()
    # edge_index = to_undirected(edge_index)
    # data = dgl.graph((edge_index[0], edge_index[1]), num_nodes=x.size(0))
    # data.ndata["feat"] = graph.ndata["feat"]
    # data.ndata["label"] = graph.ndata["label"]
    # data.ndata["train_mask"] = graph.ndata["train_mask"]
    # data.ndata["val_mask"] = graph.ndata["val_mask"]
    # data.ndata["test_mask"] = graph.ndata["test_mask"]
    # graph = data


    if linear_prob:
        with torch.no_grad():
            x = model.embed(graph.to(device), x.to(device))
            in_feat = x.shape[1]
        encoder = LogisticRegression(in_feat, num_classes)
    else:
        encoder = model.encoder
        encoder.reset_classifier(num_classes)

    num_finetune_params = [p.numel() for p in encoder.parameters() if  p.requires_grad]
    if not mute:
        print(f"num parameters for finetuning: {sum(num_finetune_params)}")
    
    encoder.to(device)
    optimizer_f = create_optimizer("adam", encoder, lr_f, weight_decay_f)
    final_acc, estp_acc = linear_probing_for_transductive_node_classiifcation(encoder, dataset,graph, x, optimizer_f, max_epoch_f, device, mute)
    return final_acc, estp_acc

def linear_probing_for_transductive_node_classiifcation(model, dataset, graph, feat, optimizer, max_epoch, device, mute=False):
    criterion = torch.nn.CrossEntropyLoss()

    graph = graph.to(device)
    x = feat.to(device)

    cla_acc = []
    es_cla_acc = []
    for i in range(1):
        if dataset == 'wikics':
            train_mask = graph.ndata["train_mask"][:, i].bool()
            val_mask = graph.ndata["val_mask"][:, i].bool()
            test_mask = graph.ndata["test_mask"].bool()
        else:
            train_mask = graph.ndata["train_mask"]
            val_mask = graph.ndata["val_mask"]
            test_mask = graph.ndata["test_mask"]
        labels = graph.ndata["label"]

        best_val_acc = 0
        best_val_epoch = 0
        best_model = None

        # if not mute:
        #     epoch_iter = tqdm(range(max_epoch))
        # else:
        #     epoch_iter = range(max_epoch)

        # 这里的encoder指线性分类器，线性分类器训练多次
        for epoch in range(max_epoch):
            model.train()
            out = model(graph, x)
            loss = criterion(out[train_mask], labels[train_mask])
            optimizer.zero_grad()
            loss.backward()
            # torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=3)
            optimizer.step()

            with torch.no_grad():
                model.eval()
                pred = model(graph, x)
                val_acc = accuracy(pred[val_mask], labels[val_mask])
                val_loss = criterion(pred[val_mask], labels[val_mask])
                test_acc = accuracy(pred[test_mask], labels[test_mask])
                test_loss = criterion(pred[test_mask], labels[test_mask])

            if val_acc >= best_val_acc:
                best_val_acc = val_acc
                best_val_epoch = epoch
                best_model = copy.deepcopy(model)

            # if not mute:
            #     epoch_iter.set_description(f"#Classification Epoch: {epoch}, train_loss:{loss.item(): .4f}, val_loss:{val_loss.item(): .4f}, val_acc:{val_acc}, test_loss:{test_loss.item(): .4f}, test_acc:{test_acc: .4f}")

        best_model.eval()
        with torch.no_grad():
            pred = best_model(graph, x)
            estp_test_acc = accuracy(pred[test_mask], labels[test_mask])
        # if mute:
        #     print(f"# IGNORE: --- TestAcc: {test_acc:.4f}, early-stopping-TestAcc: {estp_test_acc:.4f}, Best ValAcc: {best_val_acc:.4f} in cla epoch {best_val_epoch} --- ")
        # else:
        #     print(f"Classification--- TestAcc: {test_acc:.4f}, early-stopping-TestAcc: {estp_test_acc:.4f}, Best ValAcc: {best_val_acc:.4f} in cla epoch {best_val_epoch} --- ")

        cla_acc.append(test_acc)
        es_cla_acc.append(estp_test_acc)

    # (final_acc, es_acc, best_acc)
    # return test_acc, estp_test_acc
    return np.mean(cla_acc), np.mean(es_cla_acc)

# def linear_probing_for_transductive_node_classiifcation(model, dataset,graph, feat, optimizer, max_epoch, device, mute=False):
#     criterion = torch.nn.CrossEntropyLoss()
#
#     graph = graph.to(device)
#     x = feat.to(device)
#
#     train_mask = graph.ndata["train_mask"]
#     val_mask = graph.ndata["val_mask"]
#     test_mask = graph.ndata["test_mask"]
#     labels = graph.ndata["label"]
#
#     best_val_acc = 0
#     best_val_epoch = 0
#     best_model = None
#
#     if not mute:
#         epoch_iter = tqdm(range(max_epoch))
#     else:
#         epoch_iter = range(max_epoch)
#
#     for epoch in epoch_iter:
#         model.train()
#         out = model(graph, x)
#         loss = criterion(out[train_mask], labels[train_mask])
#         optimizer.zero_grad()
#         loss.backward()
#         # torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=3)
#         optimizer.step()
#
#         with torch.no_grad():
#             model.eval()
#             pred = model(graph, x)
#             val_acc = accuracy(pred[val_mask], labels[val_mask])
#             val_loss = criterion(pred[val_mask], labels[val_mask])
#             test_acc = accuracy(pred[test_mask], labels[test_mask])
#             test_loss = criterion(pred[test_mask], labels[test_mask])
#
#         if val_acc >= best_val_acc:
#             best_val_acc = val_acc
#             best_val_epoch = epoch
#             best_model = copy.deepcopy(model)
#
#         if not mute:
#             epoch_iter.set_description(f"# Epoch: {epoch}, train_loss:{loss.item(): .4f}, val_loss:{val_loss.item(): .4f}, val_acc:{val_acc}, test_loss:{test_loss.item(): .4f}, test_acc:{test_acc: .4f}")
#
#     best_model.eval()
#     with torch.no_grad():
#         pred = best_model(graph, x)
#         estp_test_acc = accuracy(pred[test_mask], labels[test_mask])
#     if mute:
#         print(f"# IGNORE: --- TestAcc: {test_acc:.4f}, early-stopping-TestAcc: {estp_test_acc:.4f}, Best ValAcc: {best_val_acc:.4f} in epoch {best_val_epoch} --- ")
#     else:
#         print(f"--- TestAcc: {test_acc:.4f}, early-stopping-TestAcc: {estp_test_acc:.4f}, Best ValAcc: {best_val_acc:.4f} in epoch {best_val_epoch} --- ")
#
#     # (final_acc, es_acc, best_acc)
#     return test_acc, estp_test_acc


def linear_probing_for_inductive_node_classiifcation(model, x, labels, mask, optimizer, max_epoch, device, mute=False):
    if len(labels.shape) > 1:
        criterion = torch.nn.BCEWithLogitsLoss()
    else:
        criterion = torch.nn.CrossEntropyLoss()
    train_mask, val_mask, test_mask = mask

    best_val_acc = 0
    best_val_epoch = 0
    best_model = None

    if not mute:
        epoch_iter = tqdm(range(max_epoch))
    else:
        epoch_iter = range(max_epoch)  

        best_val_acc = 0

    if not mute:
        epoch_iter = tqdm(range(max_epoch))
    else:
        epoch_iter = range(max_epoch)

    for epoch in epoch_iter:
        model.train()
        out = model(None, x)
        loss = criterion(out[train_mask], labels[train_mask])
        optimizer.zero_grad()
        loss.backward()
        # torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=3)
        optimizer.step()

        with torch.no_grad():
            model.eval()
            pred = model(None, x)
            val_acc = accuracy(pred[val_mask], labels[val_mask])
            val_loss = criterion(pred[val_mask], labels[val_mask])
            test_acc = accuracy(pred[test_mask], labels[test_mask])
            test_loss = criterion(pred[test_mask], labels[test_mask])
        
        if val_acc >= best_val_acc:
            best_val_acc = val_acc
            best_val_epoch = epoch
            best_model = copy.deepcopy(model)

        if not mute:
            epoch_iter.set_description(f"# Epoch: {epoch}, train_loss:{loss.item(): .4f}, val_loss:{val_loss.item(): .4f}, val_acc:{val_acc}, test_loss:{test_loss.item(): .4f}, test_acc:{test_acc: .4f}")

    best_model.eval()
    with torch.no_grad():
        pred = best_model(None, x)
        estp_test_acc = accuracy(pred[test_mask], labels[test_mask])
    if mute:
        print(f"# IGNORE: --- TestAcc: {test_acc:.4f}, early-stopping-TestAcc: {estp_test_acc:.4f}, Best ValAcc: {best_val_acc:.4f} in epoch {best_val_epoch} ")
    else:
        print(f"--- TestAcc: {test_acc:.4f}, early-stopping-TestAcc: {estp_test_acc:.4f}, Best ValAcc: {best_val_acc:.4f} in epoch {best_val_epoch}")

    return test_acc, estp_test_acc


class LogisticRegression(nn.Module):
    def __init__(self, num_dim, num_class):
        super().__init__()
        self.linear = nn.Linear(num_dim, num_class)

    def forward(self, g, x, *args):
        logits = self.linear(x)
        return logits
