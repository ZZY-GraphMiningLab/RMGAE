import json
from collections import namedtuple, Counter
import numpy as np
import scipy.sparse as sp

import torch
import torch.nn.functional as F

import dgl
import networkx as nx

from dgl.data import (
    load_data,
    TUDataset,
    CoraGraphDataset,
    CiteseerGraphDataset,
    PubmedGraphDataset,
    AmazonCoBuyPhotoDataset, AmazonCoBuyComputerDataset,
    CoauthorCSDataset, CoauthorPhysicsDataset,
    WikiCSDataset
)
from torch_geometric.datasets import Planetoid, Amazon, Coauthor
from ogb.nodeproppred import DglNodePropPredDataset
from dgl.data.ppi import PPIDataset
from dgl.dataloading import GraphDataLoader
from deeprobust.graph.data import Dataset, PrePtbDataset, Dpr2Pyg, Pyg2Dpr
from sklearn.preprocessing import StandardScaler
from torch_geometric.utils import to_undirected, dense_to_sparse, to_dense_adj


def to_numpy(*inputs, full_reduce=True):
    """将输入数据（Tensor/列表/标量）转换为 NumPy 数组或 Python 原生标量

    Args:
        inputs: 可变参数，支持任意数量的 Tensor、列表、数字等
        full_reduce: 是否将形状为 (1,) 的数组降维为标量（默认True）

    Returns:
        单个输入 → 返回 NumPy 数组或标量
        多个输入 → 返回包含转换结果的列表
    """
    outputs = []
    for data in inputs:
        # 处理 PyTorch Tensor
        if isinstance(data, torch.Tensor):
            data = data.detach().cpu().numpy()  # 脱离计算图 + 转移到CPU

        # 处理列表/元组
        elif isinstance(data, (list, tuple)):
            data = np.array(data)

        # 处理单个元素的数组降维
        if isinstance(data, np.ndarray):
            if full_reduce and data.shape == (1,):
                data = data.item()  # 形状 (1,) → 标量
            elif data.shape == ():
                data = data.item()  # 零维数组 → 标量

        outputs.append(data)

    return outputs[0] if len(outputs) == 1 else outputs


def edge_index_2_csr(edge_index, size):
    """Edge index (PyG COO format) transformed to csr format."""
    csr_matrix = sp.csr_matrix(
        (np.ones(edge_index.shape[1]), to_numpy(edge_index)),
        shape=(size, size))
    return csr_matrix


def process_data_for_nettack(data):
    data.features = sp.csr_matrix(to_numpy(data.ndata["feat"]))
    data.adj = edge_index_2_csr(torch.stack([data.edges()[0], data.edges()[1]], dim=0),
                                size=data.ndata["feat"].shape[0])
    data.labels = to_numpy(data.ndata["label"])
    data.idx_train = np.where(to_numpy(data.ndata["train_mask"]))[0]
    data.idx_val = np.where(to_numpy(data.ndata["val_mask"]))[0]
    data.idx_test = np.where(to_numpy(data.ndata["test_mask"]))[0]
    return data


GRAPH_DICT = {
    "cora": CoraGraphDataset,
    "citeseer": CiteseerGraphDataset,
    "pubmed": PubmedGraphDataset,
    "ogbn-arxiv": DglNodePropPredDataset,
    "wikics": WikiCSDataset,
    "photo": AmazonCoBuyPhotoDataset,
    "computers": AmazonCoBuyComputerDataset,
    "cs": CoauthorCSDataset,
    "physics": CoauthorPhysicsDataset
}


def get_neighbors(g, u, include_self_loop=True):
    neighbors = torch.cat([g.predecessors(u), g.successors(u)]).unique()
    if include_self_loop:
        neighbors = neighbors[neighbors != u.item()]
    return neighbors


def getLCC(g):
    # 转换为无向图
    g.cpu()
    g = g.remove_self_loop()
    # 转换为NetworkX无向图
    nx_graph = nx.Graph()
    nx_graph.add_nodes_from(range(g.num_nodes()))
    src, dst = g.edges()
    edges = list(zip(src.tolist(), dst.tolist()))  # 获取边列表
    nx_graph.add_edges_from(edges)  # 添加所有边
    # 计算局部聚类系数
    lcc_dict = nx.clustering(nx_graph)

    # 转为 tensor，确保顺序与原始图一致
    lcc_tensor = torch.tensor([lcc_dict[i] for i in range(g.num_nodes())], dtype=torch.float)

    # lcc = []
    # dgl.to_networkx(g.cpu(), g.ndata, g.edata)
    # for node in g.nodes():
    #     neighbors = get_neighbors(g, node, include_self_loop=True)
    #     k = len(neighbors)
    #     if k<2:
    #         clustering=0
    #     else:
    #         triplets=0
    #         for i in range(k):
    #             for j in range(i+1,k):
    #                 if g.has_edges_between(neighbors[i], neighbors[j]):
    #                     triplets += 1
    #         clustering = 2*triplets/(k*(k-1))
    #     lcc.append(clustering)
    return lcc_tensor


def preprocess(graph):
    feat = graph.ndata["feat"]
    graph = dgl.to_bidirected(graph)
    graph.ndata["feat"] = feat

    graph = graph.remove_self_loop().add_self_loop()
    graph.create_formats_()
    return graph


def scale_feats(x):
    scaler = StandardScaler()
    feats = x.numpy()
    scaler.fit(feats)
    feats = torch.from_numpy(scaler.transform(feats)).float()
    return feats


def create_masks(data):
    """
    Splits data into training, validation, and test splits in a stratified manner if
    it is not already splitted. Each split is associated with a mask vector, which
    specifies the indices for that split. The data will be modified in-place
    :param data: Data object
    :return: The modified data
    """
    tr = 0.1
    vl = 0.1
    tst = 0.8

    _train_mask = _val_mask = _test_mask = None

    labels = data.ndata['label'].numpy()
    dev_size = int(labels.shape[0] * vl)
    test_size = int(labels.shape[0] * tst)

    perm = np.random.permutation(labels.shape[0])
    test_index = perm[:test_size]
    dev_index = perm[test_size:test_size + dev_size]

    data_index = np.arange(labels.shape[0])
    test_mask = torch.tensor(np.in1d(data_index, test_index), dtype=torch.bool)
    dev_mask = torch.tensor(np.in1d(data_index, dev_index), dtype=torch.bool)
    train_mask = ~(dev_mask + test_mask)
    test_mask = test_mask.reshape(1, -1)
    dev_mask = dev_mask.reshape(1, -1)
    train_mask = train_mask.reshape(1, -1)


    data.ndata["train_mask"] = train_mask.squeeze()
    data.ndata["val_mask"] = dev_mask.squeeze()
    data.ndata["test_mask"] = test_mask.squeeze()
# data.train_mask = _train_mask.squeeze()
# data.val_mask = _val_mask.squeeze()
# data.test_mask = _test_mask.squeeze()


    return data

# def get_nettack(graph):
#     device = graph.device
#     x = graph.ndata['feat']
#     train_mask = graph.ndata["train_mask"]
#     val_mask = graph.ndata["val_mask"]
#     test_mask = graph.ndata["test_mask"]
#     label = graph.ndata["label"]
#     idx_test = test_mask.nonzero().squeeze().cpu().detach().numpy()
#     idx_train = train_mask.nonzero().squeeze().cpu().detach().numpy()
#     # y = labels.to(device)
#     edge_index = torch.stack([graph.edges()[0], graph.edges()[1]], dim=0)
#     data = process_data_for_nettack(graph)
#     surrogate_model = GCN(nfeat=x.shape[1], nclass=num_classes,
#                           nhid=16, dropout=0, with_relu=False, with_bias=False, device=device).to(device)
#     surrogate_model.fit(data.features, data.adj, data.labels, data.idx_train)
#
#
#     n_perturbations = 4
#     perturbations = 100
#     data = torch.load('{}_{}_nettack_pubmed.pth'.format(perturbations,n_perturbations))
#     node_list = data.node_list
#
#     #
#     cnt = 0
#     features, adj, labels = data.features, data.adj, data.labels
#
#     pre_num = int(perturbations * graph.num_nodes())
#     pre_num = 100
#     node_list = select_nodes(pre_num,features,lr_f, weight_decay_f, model,graph,x, num_classes,labels, adj, idx_train, idx_test, device)
#     for target_node in tqdm(node_list):
#         features, adj, labels = data.features, data.adj, data.labels
#         nettack = Nettack(surrogate_model, nnodes=x.size(0), attack_structure=True,attack_features=True,
#                           device=device).to(device)
#         nettack = nettack.to(device)
#         nettack.attack(features, adj, labels, target_node, n_perturbations=n_perturbations,direct=True, verbose=True)
#         adj_coo = nettack.modified_adj.tocoo()
#         tr1 =to_Variable(adj_coo.row, adj_coo.col)[0].long().to(x.device)
#         tr2 =to_Variable(adj_coo.row, adj_coo.col)[1].long().to(x.device)
#         data = dgl.graph((tr1, tr2), num_nodes=x.size(0))
#         data.ndata["feat"] = to_Variable(nettack.modified_features.toarray()).to(x.device)
#         data.ndata["label"] = label
#         data.ndata["train_mask"]=train_mask
#         data.ndata["val_mask"]=val_mask
#         data.ndata["test_mask"]=test_mask
#         data = process_data_for_nettack(data)
#     data.node_list = node_list
#     torch.save(data, '{}_{}_nettack_pubmed.pth'.format(perturbations,n_perturbations))
def dgl_random_flip_attack_fast(g, ptb, seed=None):
    """
    Efficient random flip attack for DGLGraph (undirected)

    Parameters
    ----------
    g : dgl.DGLGraph
        无向图（双向存边）
    ptb : float
        perturbation rate
    seed : int or None

    Returns
    -------
    g_attacked : dgl.DGLGraph
    """

    if seed is not None:
        torch.manual_seed(seed)

    g = g.clone()
    num_nodes = g.num_nodes()

    # ===== 1. 扰动数量（严格对齐 adj.sum() // 2）=====
    num_edges = g.num_edges() // 2
    n_perturb = int(ptb * num_edges)

    # ===== 2. 当前边集合（无向，去重）=====
    src, dst = g.edges()
    src = src.tolist()
    dst = dst.tolist()

    edge_set = set()
    for u, v in zip(src, dst):
        if u != v:
            edge_set.add((min(u, v), max(u, v)))

    # ===== 3. 一次性随机采样候选节点对 =====
    # 采样数量稍微放大，减少 while
    sample_size = int(n_perturb * 1.5) + 10

    u = torch.randint(0, num_nodes, (sample_size,))
    v = torch.randint(0, num_nodes, (sample_size,))

    added = []
    removed = []

    used = set()

    for ui, vi in zip(u.tolist(), v.tolist()):
        if len(added) + len(removed) >= n_perturb:
            break

        if ui == vi:
            continue

        e = (min(ui, vi), max(ui, vi))
        if e in used:
            continue
        used.add(e)

        if e in edge_set:
            removed.append(e)
        else:
            added.append(e)

    # ===== 4. 批量删除边 =====
    if removed:
        rem_src = []
        rem_dst = []
        for u, v in removed:
            rem_src.extend([u, v])
            rem_dst.extend([v, u])

        eids = g.edge_ids(rem_src, rem_dst)
        g.remove_edges(eids)

    # ===== 5. 批量加边 =====
    if added:
        add_src = []
        add_dst = []
        for u, v in added:
            add_src.extend([u, v])
            add_dst.extend([v, u])

        g.add_edges(add_src, add_dst)

    return g
def load_dataset(dataset_name,args):
    assert dataset_name in GRAPH_DICT, f"Unknow dataset: {dataset_name}."

    if dataset_name.startswith("ogbn"):
        dataset = GRAPH_DICT[dataset_name](dataset_name)
    else:
        dataset = GRAPH_DICT[dataset_name]()

    citegraph = ['cora', 'citeseer', 'pubmed', 'wikics']
    cograph = ['photo', 'computers', 'cs', 'physics']
    if dataset_name == "ogbn-arxiv":
        graph, labels = dataset[0]
        num_nodes = graph.num_nodes()

        split_idx = dataset.get_idx_split()
        train_idx, val_idx, test_idx = split_idx["train"], split_idx["valid"], split_idx["test"]
        graph = preprocess(graph)

        if not torch.is_tensor(train_idx):
            train_idx = torch.as_tensor(train_idx)
            val_idx = torch.as_tensor(val_idx)
            test_idx = torch.as_tensor(test_idx)

        feat = graph.ndata["feat"]
        feat = scale_feats(feat)
        graph.ndata["feat"] = feat

        train_mask = torch.full((num_nodes,), False).index_fill_(0, train_idx, True)
        val_mask = torch.full((num_nodes,), False).index_fill_(0, val_idx, True)
        test_mask = torch.full((num_nodes,), False).index_fill_(0, test_idx, True)
        graph.ndata["label"] = labels.view(-1)
        graph.ndata["train_mask"], graph.ndata["val_mask"], graph.ndata["test_mask"] = train_mask, val_mask, test_mask
    elif dataset_name in citegraph:
        '''
            deeprobust_mettack攻击数据
        '''
        if args.attack == "mettack":
            ptb = args.ptb
            data = Dataset(root='./data/dataset', name=dataset_name, setting='prognn')
            perturbed_data = PrePtbDataset(root='./data/dataset',
                                           name=dataset_name,
                                           attack_method='meta',
                                           ptb_rate=ptb)

            perturbed_adj = perturbed_data.adj
            edge_index = dense_to_sparse(torch.from_numpy(perturbed_adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)
            pyg_data = Dpr2Pyg(data)
            graph = dgl.graph((edge_index[0], edge_index[1]), num_nodes=pyg_data[0].x.size(0))
            graph.ndata["feat"] = pyg_data[0].x
            graph.ndata["label"] = pyg_data[0].y
            graph.ndata["train_mask"] = pyg_data[0].train_mask
            graph.ndata["val_mask"] = pyg_data[0].val_mask
            graph.ndata["test_mask"] = pyg_data[0].test_mask

        '''
            prognn干净数据
        '''
        if args.attack == "clean":
            data = Dataset(root='./data/dataset', name=dataset_name,setting='prognn')
            # adj, features, labels = data.adj, data.features, data.labels
            # idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test
            pyg_data = Dpr2Pyg(data)
            graph = dgl.graph((pyg_data[0].edge_index[0], pyg_data[0].edge_index[1]), num_nodes=pyg_data[0].x.size(0))
            graph.ndata["feat"] = pyg_data[0].x
            graph.ndata["label"] = pyg_data[0].y
            graph.ndata["train_mask"] = pyg_data[0].train_mask
            graph.ndata["val_mask"] = pyg_data[0].val_mask
            if args.ptb > 5:
                with open('./nettack/{}_nettacked_nodes.json'.format(dataset_name), 'r') as json_file:
                    noo = json.load(json_file)
                attacked_test_nodes = noo["attacked_test_nodes"]
                mask = torch.zeros(pyg_data[0].x.size(0), dtype=torch.bool)
                mask[attacked_test_nodes] = True
                graph.ndata["test_mask"] = mask
            else:
                graph.ndata["test_mask"] = pyg_data[0].test_mask

        # graph = dataset[0]

        '''
                nettack攻击数据
        '''
        if args.attack == "nettack":

            ptb = args.ptb
            data = Dataset(root='./data/dataset', name=dataset_name, setting='prognn')
            pyg_data = Dpr2Pyg(data)

            perturbed_data = PrePtbDataset(root='./nettack/',
                                           name=dataset_name,
                                           attack_method='nettack',
                                           ptb_rate=ptb)
            adj = perturbed_data.adj
            edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)
            data = dgl.graph((edge_index[0], edge_index[1]), num_nodes=pyg_data[0].x.size(0))
            data.ndata["feat"] = pyg_data[0].x
            data.ndata["label"] = pyg_data[0].y
            data.ndata["train_mask"] = pyg_data[0].train_mask
            data.ndata["val_mask"] = pyg_data[0].val_mask

            idx_test = perturbed_data.target_nodes
            mask = torch.zeros(pyg_data[0].x.size(0), dtype=torch.bool)
            mask[idx_test] = True
            data.ndata["test_mask"] = mask
            graph = data

        if args.attack == 'dice':
            ptb = args.ptb
            data = Dataset(root='./data/dataset', name=dataset_name, setting='prognn')
            adj,labl = data.adj, data.labels
            from deeprobust.graph.global_attack import DICE
            attacker = DICE()
            n_perturbations = int(ptb * (adj.sum() // 2))
            attacker.attack(adj, labl, n_perturbations=n_perturbations)
            adj = attacker.modified_adj
            edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)
            pyg_data = Dpr2Pyg(data)
            graph = dgl.graph((edge_index[0], edge_index[1]), num_nodes=pyg_data[0].x.size(0))
            graph.ndata["feat"] = pyg_data[0].x
            graph.ndata["label"] = pyg_data[0].y
            graph.ndata["train_mask"] = pyg_data[0].train_mask
            graph.ndata["val_mask"] = pyg_data[0].val_mask
            graph.ndata["test_mask"] = pyg_data[0].test_mask
            graph = graph.remove_self_loop()
            graph = graph.add_self_loop()

        if args.attack == "random":
            ptb = args.ptb
            data = Dataset(root='./data/dataset', name=dataset_name, setting='prognn')
            print("random attack with rate %.2f" % ptb)
            from deeprobust.graph.global_attack import Random
            adj = data.adj
            # to fix the seed of generated random attack, you need to fix both np.random and random
            # you can uncomment the following code
            # import random
            # random.seed(args.seed)
            # np.random.seed(args.seed)
            attacker = Random()
            n_perturbations = int(ptb * (adj.sum() // 2))
            attacker.attack(adj, n_perturbations, type='add')
            adj = attacker.modified_adj
            edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)
            pyg_data = Dpr2Pyg(data)
            graph = dgl.graph((edge_index[0], edge_index[1]), num_nodes=pyg_data[0].x.size(0))
            graph.ndata["feat"] = pyg_data[0].x
            graph.ndata["label"] = pyg_data[0].y
            graph.ndata["train_mask"] = pyg_data[0].train_mask
            graph.ndata["val_mask"] = pyg_data[0].val_mask
            graph.ndata["test_mask"] = pyg_data[0].test_mask
        '''
            FGA
        '''
        # ptb_rate = 1
        # root = './FGA_Data/'
        # print('Reading structure from', root)
        # adj = sp.load_npz(root + dataset_name + '_FGA_adj_' + str(ptb_rate) + '.npz')
        # edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
        # edge_index = to_undirected(edge_index)
        # data = dgl.graph((edge_index[0], edge_index[1]), num_nodes=graph.num_nodes())
        # data.ndata["feat"] = graph.ndata["feat"]
        # data.ndata["label"] = graph.ndata["label"]
        # data.ndata["train_mask"] = graph.ndata["train_mask"]
        # data.ndata["val_mask"] = graph.ndata["val_mask"]
        # json_file = root + dataset_name + '_FGA_nodes.json'
        # with open(json_file, 'r') as f:
        #     idx = json.loads(f.read())
        # idx_test = idx["attacked_test_nodes"]
        # idx_test = np.array(idx_test)
        # mask = torch.zeros(graph.num_nodes(), dtype=torch.bool)
        # mask[idx_test] = True
        # data.ndata["test_mask"] = mask
        # graph = data
        #
        # graph = graph.remove_self_loop()
        # graph = graph.add_self_loop()
        '''
            mettack
        '''
        # data = process_data_for_nettack(graph)
        # features, adj, labels = data.features, data.adj, data.labels
        # perturbations = int(0.2 * (adj.sum() // 2))
        # data = torch.load('./mettack/mettack_{}_{}.pth'.format(dataset_name,perturbations))
        # graph = data
    elif dataset_name in cograph:

        # graph = Amazon(root='/data/dataset', name=dataset_name)
        graph = Amazon(root='./data/dataset/', name=dataset_name)[0]
        '''
            mettack================
        '''
        # data = graph.edge_index
        if args.attack=="mettack":
            print("Attacked graph loading ptb:{}".format(args.ptb))
            ptb = args.ptb
            data = torch.load(f'./data/dataset/{dataset_name}_meta_adj_{ptb}.pt')
        else:
            data = graph.edge_index

        g = dgl.graph((data[0], data[1]), num_nodes=graph.x.size(0))


        if args.attack=="random":
            g = dgl_random_flip_attack_fast(g,args.ptb)

        g.ndata["feat"] = graph.x
        g.ndata["label"] = graph.y
        g = create_masks(g)
        g = g.remove_self_loop()
        g = g.add_self_loop()
        graph = g
        '''
            end=================
        '''

        # graph = graph.remove_self_loop()
        # graph = graph.add_self_loop()
        # train_ratio = 0.1
        # val_ratio = 0.1
        # test_ratio = 0.8
        #
        # N = graph.number_of_nodes()
        # train_num = int(N * train_ratio)
        # val_num = int(N * (train_ratio + val_ratio))
        #
        # idx = np.arange(N)
        # np.random.shuffle(idx)
        #
        # train_idx = torch.tensor(idx[:train_num])
        # val_idx = torch.tensor(idx[train_num:val_num])
        # test_idx = torch.tensor(idx[val_num:])
        #
        # train_mask = torch.full((N,), False).index_fill_(0, train_idx, True)
        # val_mask = torch.full((N,), False).index_fill_(0, val_idx, True)
        # test_mask = torch.full((N,), False).index_fill_(0, test_idx, True)
        # graph.ndata["train_mask"], graph.ndata["val_mask"], graph.ndata["test_mask"] = train_mask, val_mask, test_mask
    # Use exactly one self-loop per node for message passing and degree computation.
    graph = graph.remove_self_loop()
    graph = graph.add_self_loop()
    num_features = graph.ndata["feat"].shape[1]
    num_classes = dataset.num_classes
    return graph, (num_features, num_classes)


def load_inductive_dataset(dataset_name):
    if dataset_name == "ppi":
        batch_size = 2
        # define loss function
        # create the dataset
        train_dataset = PPIDataset(mode='train')
        valid_dataset = PPIDataset(mode='valid')
        test_dataset = PPIDataset(mode='test')
        train_dataloader = GraphDataLoader(train_dataset, batch_size=batch_size)
        valid_dataloader = GraphDataLoader(valid_dataset, batch_size=batch_size, shuffle=False)
        test_dataloader = GraphDataLoader(test_dataset, batch_size=batch_size, shuffle=False)
        eval_train_dataloader = GraphDataLoader(train_dataset, batch_size=batch_size, shuffle=False)
        g = train_dataset[0]
        num_classes = train_dataset.num_labels
        num_features = g.ndata['feat'].shape[1]
    else:
        _args = namedtuple("dt", "dataset")
        dt = _args(dataset_name)
        batch_size = 1
        dataset = load_data(dt)
        num_classes = dataset.num_classes

        g = dataset[0]
        num_features = g.ndata["feat"].shape[1]

        train_mask = g.ndata['train_mask']
        feat = g.ndata["feat"]
        feat = scale_feats(feat)
        g.ndata["feat"] = feat

        g = g.remove_self_loop()
        g = g.add_self_loop()

        train_nid = np.nonzero(train_mask.data.numpy())[0].astype(np.int64)
        train_g = dgl.node_subgraph(g, train_nid)
        train_dataloader = [train_g]
        valid_dataloader = [g]
        test_dataloader = valid_dataloader
        eval_train_dataloader = [train_g]

    return train_dataloader, valid_dataloader, test_dataloader, eval_train_dataloader, num_features, num_classes


def load_graph_classification_dataset(dataset_name, deg4feat=False):
    dataset_name = dataset_name.upper()
    dataset = TUDataset(dataset_name)
    graph, _ = dataset[0]

    if "attr" not in graph.ndata:
        if "node_labels" in graph.ndata and not deg4feat:
            print("Use node label as node features")
            feature_dim = 0
            for g, _ in dataset:
                feature_dim = max(feature_dim, g.ndata["node_labels"].max().item())

            feature_dim += 1
            for g, l in dataset:
                node_label = g.ndata["node_labels"].view(-1)
                feat = F.one_hot(node_label, num_classes=feature_dim).float()
                g.ndata["attr"] = feat
        else:
            print("Using degree as node features")
            feature_dim = 0
            degrees = []
            for g, _ in dataset:
                feature_dim = max(feature_dim, g.in_degrees().max().item())
                degrees.extend(g.in_degrees().tolist())
            MAX_DEGREES = 400

            oversize = 0
            for d, n in Counter(degrees).items():
                if d > MAX_DEGREES:
                    oversize += n
            # print(f"N > {MAX_DEGREES}, #NUM: {oversize}, ratio: {oversize/sum(degrees):.8f}")
            feature_dim = min(feature_dim, MAX_DEGREES)

            feature_dim += 1
            for g, l in dataset:
                degrees = g.in_degrees()
                degrees[degrees > MAX_DEGREES] = MAX_DEGREES

                feat = F.one_hot(degrees, num_classes=feature_dim).float()
                g.ndata["attr"] = feat
    else:
        print("******** Use `attr` as node features ********")
        feature_dim = graph.ndata["attr"].shape[1]

    labels = torch.tensor([x[1] for x in dataset])

    num_classes = torch.max(labels).item() + 1
    dataset = [(g.remove_self_loop().add_self_loop(), y) for g, y in dataset]

    print(f"******** # Num Graphs: {len(dataset)}, # Num Feat: {feature_dim}, # Num Classes: {num_classes} ********")

    return dataset, (feature_dim, num_classes)
